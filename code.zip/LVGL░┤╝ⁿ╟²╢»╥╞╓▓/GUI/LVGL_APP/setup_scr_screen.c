/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */

#include "lvgl/lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
//#include "custom.h"



extern lv_indev_t * indev_keypad;

lv_obj_t *list1;
static lv_obj_t * list_btns[6];
static const char* list_item_name[] ={
	"Snake",
	"Tank",
	"Tetris",
	"2048",
	"Hit&Plane",
	"Block",
};


//�¼��ص�����
static void list_handler(lv_obj_t * obj, lv_event_t event)
{
   
	if(event == LV_EVENT_KEY)
	{
		const uint32_t *key = lv_event_get_data();
		if(*key==LV_KEY_ENTER)
		{
			lv_obj_t *select = lv_list_get_btn_selected(obj);
			printf("Clicked: %s\n", lv_list_get_btn_text(select));
		}
	}
}


void setup_scr_screen(lv_ui *ui){

	//Write codes screen
	ui->screen = lv_obj_create(NULL, NULL);
  lv_group_t *group1 = lv_group_create();
//	lv_group_t *group2 = lv_group_create();
	lv_indev_set_group(indev_keypad, group1);
//	lv_indev_set_group(indev_keypad, group2);
	//Write codes screen_btn_1
	ui->screen_btn_1 = lv_btn_create(ui->screen, NULL);

	//Write style LV_BTN_PART_MAIN for screen_btn_1
	static lv_style_t style_screen_btn_1_main;
	lv_style_reset(&style_screen_btn_1_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_btn_1_main
	lv_style_set_radius(&style_screen_btn_1_main, LV_STATE_DEFAULT, 50);
	lv_style_set_bg_color(&style_screen_btn_1_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_btn_1_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_btn_1_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_btn_1_main, LV_STATE_DEFAULT, 255);
	lv_style_set_border_color(&style_screen_btn_1_main, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_border_width(&style_screen_btn_1_main, LV_STATE_DEFAULT, 2);
	lv_style_set_border_opa(&style_screen_btn_1_main, LV_STATE_DEFAULT, 255);
	lv_style_set_outline_color(&style_screen_btn_1_main, LV_STATE_DEFAULT, lv_color_make(0xd4, 0xd7, 0xd9));
	lv_style_set_outline_opa(&style_screen_btn_1_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_btn_1, LV_BTN_PART_MAIN, &style_screen_btn_1_main);
	lv_obj_set_pos(ui->screen_btn_1, 113, 112);
	lv_obj_set_size(ui->screen_btn_1, 100, 50);
	ui->screen_btn_1_label = lv_label_create(ui->screen_btn_1, NULL);
	lv_label_set_text(ui->screen_btn_1_label, "default");
	lv_obj_set_style_local_text_color(ui->screen_btn_1_label, LV_LABEL_PART_MAIN, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_obj_set_style_local_text_font(ui->screen_btn_1_label, LV_LABEL_PART_MAIN, LV_STATE_DEFAULT, &lv_font_simsun_12);

  lv_obj_t *btn2 = lv_btn_create(ui->screen,NULL);
//	lv_obj_align(btn2,NULL,LV_ALIGN_OUT_BOTTOM_MID,0,20);
	lv_obj_t *label2 = lv_label_create(btn2,NULL);
	lv_label_set_text(label2,"btn2");
	lv_obj_align(btn2,ui->screen,LV_ALIGN_IN_TOP_MID,0,0);

	lv_obj_t *btn3 = lv_btn_create(ui->screen,NULL);
	lv_obj_align(btn3,btn2,LV_ALIGN_OUT_BOTTOM_MID,0,20);
	lv_obj_t *label3 = lv_label_create(btn3,NULL);
	lv_label_set_text(label3,"btn3");
//	
  lv_obj_t * roller1 = lv_roller_create(ui->screen,NULL);
	lv_roller_set_options(roller1,"Shanghai\nBeijing\nShenzhen\nGuangzhou\nHangzhou\nNanchang",LV_ROLLER_MODE_INIFINITE);//�������е�ѡ��ֵ,ѭ������ģʽ
	lv_roller_set_selected(roller1,3,LV_ANIM_OFF);//����Ĭ��ѡ��ֵΪGuangzhou
	lv_roller_set_fix_width(roller1,140);//���ù̶�����
	lv_roller_set_visible_row_count(roller1,4);//���ÿɼ�������
//	lv_obj_set_event_cb(roller1,event_handler);//ע���¼��ص�����
	lv_obj_align(roller1,btn3,LV_ALIGN_OUT_BOTTOM_MID,0,20);//��������Ļ���ж���
	
	list1 = lv_list_create(ui->screen,NULL);
	lv_obj_set_size(list1,100,150);
	lv_obj_align (list1,roller1,LV_ALIGN_OUT_BOTTOM_MID,0,20);
	uint8_t i;
	for(i=0;i<6;i++)
	{
		list_btns[i] = lv_list_add_btn(list1, NULL, list_item_name[i]);
	}
	lv_obj_set_event_cb(list1,list_handler);
	
	lv_group_add_obj(group1,btn2);
	lv_group_add_obj(group1,btn3);
  lv_group_add_obj(group1,roller1);
	lv_group_add_obj(group1,list1);

}
