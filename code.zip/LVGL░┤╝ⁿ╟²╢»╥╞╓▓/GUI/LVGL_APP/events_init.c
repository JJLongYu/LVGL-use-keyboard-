/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */

#include "events_init.h"
#include <stdio.h>
#include "lvgl/lvgl.h"

void events_init_screen(lv_ui *ui);

void events_init(lv_ui *ui)
{
	events_init_screen(ui);
}

static void screen_btn_1event_handler(lv_obj_t * obj, lv_event_t event)
{
	switch (event)
	{
	case LV_EVENT_RELEASED:
	{
		lv_obj_set_style_local_bg_grad_color(guider_ui.screen_btn_1, LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, lv_color_make(0xc9, 0x1d, 0x1d));
	}
		break;
	default:
		break;
	}
}

void events_init_screen(lv_ui *ui)
{
	lv_obj_set_event_cb(ui->screen_btn_1, screen_btn_1event_handler);
}


